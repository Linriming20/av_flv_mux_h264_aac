#include <stdio.h>
#include "flv.h"

int main(int argc, char *argv[])
{
    conver2Flv("hulu.h264", "out.flv");

    return 0;
}

